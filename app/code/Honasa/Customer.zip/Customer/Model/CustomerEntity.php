<?php

namespace Honasa\Customer\Model;

use Exception;
use Honasa\Customer\Api\CustomerEntityInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;


/**
 * Defines the implementaiton class of the calculator service contract.
 */
class CustomerEntity implements CustomerEntityInterface
{
    const CUSTOMER_ENTITY_RESOURCE = 'Customer_Entity';

    /** @var SearchCriteriaBuilder */
    protected $searchCriteriaBuilder;

    public function __construct(
        \Magento\Store\Model\StoreManagerInterface        $storeManager,
        \Magento\Framework\Api\SearchCriteriaBuilder      $searchCriteriaBuilder,
        \Magento\Customer\Model\CustomerFactory           $customerFactory,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Magento\Integration\Model\Oauth\TokenFactory     $tokenModelFactory,
        array                                             $data = []
    )
    {
        $this->storeManager = $storeManager;
        $this->_storeManager = $storeManager;
        $this->customerFactory = $customerFactory;
        $this->customerRepository = $customerRepository;
        $this->tokenModelFactory = $tokenModelFactory;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
    }

    public function registerCustomer($customerData)
    {
        $response = [
            'status' => 200,
            'resource' => self::CUSTOMER_ENTITY_RESOURCE,
            'message' => 'Customer Entity Creation Failed',
            'data' => []
        ];
        try {
            $websiteId = $this->_storeManager->getStore()->getWebsiteId();
            $firstName = $customerData['firstName'];
            $lastName = $customerData['lastName'];
            $phone = $customerData['phone'];
            $email = $customerData['email'];
            $password = $customerData['password'];
            $gender = $customerData['gender'];
            if (isset($email) && isset($phone) && isset($firstName) && isset($lastName) && isset($gender)) {
                $customer = $this->customerFactory->create();
                $customer->setWebsiteId($websiteId);
                $customer->setEmail($email);
                $customer->setFirstname($firstName);
                $customer->setLastname($lastName);
                $customer->setForceConfirmed(true);
                $customer->setCustomAttribute('mobile_number', $phone);
                $customer->save();
                $customerId = $customer->getId();
                if (isset($customerId) && !is_null($customerId)) {
                    $customerToken = $this->_tokenModelFactory->create();
                    $tokenKey = $customerToken->createCustomerToken($customerId)->getToken();
                    $response['message'] = $customer->getData();
                    $response['token'] = $tokenKey;
                    $response['data'] = $customer->getData();
                }
            }

            return $response;

        } catch (Exception $e) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __('Customer Registration Failed')
            );
        }

        return $response;
    }

    public function getCustomerDetailsById($customerId)
    {
        $response = [
            'status' => 200,
            'resource' => self::CUSTOMER_ENTITY_RESOURCE,
            'message' => 'No Products Found',
            'data' => []
        ];

        return $response;
    }

    public function getCustomerOrderDetailsById($customerId)
    {
        $response = [
            'status' => 200,
            'resource' => self::CUSTOMER_ENTITY_RESOURCE,
            'message' => 'No Products Found',
            'data' => []
        ];

        return $response;
    }

    public function getCustomerAddresses($customerId)
    {
        $response = [
            'status' => 200,
            'resource' => self::CUSTOMER_ENTITY_RESOURCE,
            'message' => 'No Products Found',
            'data' => []
        ];

        return $response;
    }

    public function getCustomerWalletBalance($customerId)
    {
        $response = [
            'status' => 200,
            'resource' => self::CUSTOMER_ENTITY_RESOURCE,
            'message' => 'No Products Found',
            'data' => []
        ];

        return $response;
    }
}
